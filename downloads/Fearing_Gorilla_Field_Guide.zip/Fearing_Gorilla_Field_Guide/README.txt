FEARING GORILLA FIELD GUIDE — BROWSER APP

WINDOWS INSTALL
1. Extract this ZIP into a folder.
2. Double-click Install_Field_Guide.vbs. The installer runs with no DOS window.
3. Use the Fearing Gorilla Field Guide shortcut on your desktop.
The guide opens in your default web browser. No PowerShell, Python, Node, or administrator rights are needed.
The hidden launcher runs the command-file installer without using PowerShell.
Installation errors are shown in a message box; the browser opens on success.
Files are installed in your user’s LocalAppData/FearingGorillaFieldGuide folder.

WITHOUT INSTALLING
Open app/index.html in any modern browser, or double-click Open_Field_Guide.vbs on Windows.
Text, controls, and nine supplied creature images work offline. Remaining video thumbnails and source links need internet access.

USE
Choose Monsters, Gods, Shrines, or Maps at the top. Each of eight cards has its own dropdown.
Click a card or its Expand button to enlarge all its details. Double-click its picture for a larger view.
Use Fit picture or Zoom 2x; double-click the large picture to toggle zoom. Escape closes the view.
God cards are red; Monster cards are green. All text is bold black Courier.
Scroll inside a card to read the full details. Mountains is marked To be announced.
Creature categories are only God and Monster; provisional classifications are flagged.
Daisy09 and Jungarella are recorded as operator-reported ghost codes.

CANON CORRECTIONS
Skittles: God, summoned on the floor in Forest. Exact ritual and abilities not yet provided.
Error: Mines underneath Stump, four players tapping all shrine corners, about three minutes.
Mines contains four monsters; the fourth name is not established here.
Overseer phases: operator describes a glitch where monsters move inward, hitboxes overlap,
players near the center die, and the game can sometimes crash.

SOURCES AND PICTURES
Adapted from the unofficial Fearing Gorilla Wiki:
https://fearing-gorilla-vr.fandom.com/wiki/Fearing_Gorilla_Wiki
Community text is CC BY-SA unless otherwise noted. This adapted guide is CC BY-SA 4.0:
https://creativecommons.org/licenses/by-sa/4.0/
Each card links its reference. Numerical health/damage/speed values are not invented.
Nine direct wiki/model pictures supplied by the operator are now bundled at original resolution.
Overseer uses the supplied altar image, also shown on its shrine card.
The remaining video thumbnails are still labeled as unverified reference imagery.
Several pictures and gameplay details remain unavailable. No generated monster artwork is used.
Research snapshot: 3 October 2026.

All 11 map cards now have pictures. Representative biome photos are labeled, credited, and are not game screenshots. Wonderland uses a woodland reference only; its landmarks still need an actual screenshot. Mountains remains to be announced.

All 11 map cards now have pictures. Representative biome photos are labeled, credited, and are not game screenshots. Wonderland uses a woodland reference only; its landmarks still need an actual screenshot. Mountains remains to be announced.
