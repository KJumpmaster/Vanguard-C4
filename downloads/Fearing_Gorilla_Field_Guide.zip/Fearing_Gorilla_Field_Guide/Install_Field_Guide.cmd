@echo off
setlocal EnableExtensions DisableDelayedExpansion
if not defined LOCALAPPDATA goto install_failed
set "FG_INSTALL=%LOCALAPPDATA%\FearingGorillaFieldGuide"
if not exist "%FG_INSTALL%" mkdir "%FG_INSTALL%" >nul 2>&1
copy /y "%~dp0app\index.html" "%FG_INSTALL%\index.html" >nul
if errorlevel 1 goto install_failed
copy /y "%~dp0app\field-guide.ico" "%FG_INSTALL%\field-guide.ico" >nul
if errorlevel 1 goto install_failed
set "FG_DESKTOP=%USERPROFILE%\Desktop"
if defined OneDrive if exist "%OneDrive%\Desktop" set "FG_DESKTOP=%OneDrive%\Desktop"
for /f "tokens=2,*" %%A in ('reg query "HKCU\Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders" /v Desktop 2^>nul') do if /i "%%A"=="REG_SZ" set "FG_DESKTOP=%%B"
if not exist "%FG_DESKTOP%" mkdir "%FG_DESKTOP%" >nul 2>&1
if not exist "%FG_DESKTOP%" goto shortcut_failed
set "FG_SHORTCUT=%FG_DESKTOP%\Fearing Gorilla Field Guide.url"
set "FG_FILEURL=%FG_INSTALL:\=/%/index.html"
> "%FG_SHORTCUT%" echo [InternetShortcut]
if errorlevel 1 goto shortcut_failed
>> "%FG_SHORTCUT%" <nul set /p "=URL=file:///%FG_FILEURL%"
>> "%FG_SHORTCUT%" echo(
>> "%FG_SHORTCUT%" <nul set /p "=IconFile=%FG_INSTALL%\field-guide.ico"
>> "%FG_SHORTCUT%" echo(
>> "%FG_SHORTCUT%" echo IconIndex=0
if errorlevel 1 goto shortcut_failed
echo Installed. Use the Fearing Gorilla Field Guide desktop shortcut.
start "" "%FG_INSTALL%\index.html"
exit /b 0
:shortcut_failed
echo The guide was copied, but the desktop shortcut could not be created.
echo Open index.html inside this folder:
echo "%FG_INSTALL%"
start "" "%FG_INSTALL%\index.html"
exit /b 2
:install_failed
echo The guide could not be copied. Extract the complete ZIP before installing.
echo You can also open app\index.html directly without installing.
exit /b 1
