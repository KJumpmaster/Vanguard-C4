Option Explicit
Dim fs, shell, folder, command, result, failure
Set fs = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
folder = fs.GetParentFolderName(WScript.ScriptFullName)
If Not fs.FileExists(fs.BuildPath(folder, "app\index.html")) Then
    MsgBox "Extract the complete ZIP first, then run Install_Field_Guide.vbs.", 16, "Fearing Gorilla Field Guide"
    WScript.Quit 1
End If
command = Chr(34) & shell.ExpandEnvironmentStrings("%ComSpec%") & Chr(34) & " /d /c " & Chr(34) & Chr(34) & fs.BuildPath(folder, "Install_Field_Guide.cmd") & Chr(34) & Chr(34)
On Error Resume Next
result = shell.Run(command, 0, True)
failure = Err.Number
On Error GoTo 0
If failure <> 0 Then
    MsgBox "The installer could not start. You can open app\index.html directly in your browser.", 16, "Fearing Gorilla Field Guide"
    WScript.Quit 1
End If
If result = 2 Then
    MsgBox "The guide was copied, but its desktop shortcut could not be created. It is opening in your browser.", 48, "Fearing Gorilla Field Guide"
ElseIf result <> 0 Then
    MsgBox "The guide could not be copied. Extract the complete ZIP and try again, or open app\index.html directly.", 16, "Fearing Gorilla Field Guide"
End If
WScript.Quit result
