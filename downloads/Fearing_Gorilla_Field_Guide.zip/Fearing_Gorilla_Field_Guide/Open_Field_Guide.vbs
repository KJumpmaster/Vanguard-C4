Option Explicit
Dim fs, shell, target
Set fs = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
target = fs.BuildPath(fs.GetParentFolderName(WScript.ScriptFullName), "app\index.html")
shell.Run Chr(34) & target & Chr(34), 0, False
